# Ejercicio 2: Servidor TCP  
# Seminario 4: Seminario aplicación cliente - servidor 
# Fundamentos de Redes (FR)
# Autor: Julia Caleya Sánchez - jcaleyas@ugr.es 
# Curso 2023 - 2024

import socket

# creamos un socket TCP (desde la aplicación se ve como un stream de bytes)
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# indicamos en qué puerto debe escuchar. En los clientes no hace falta, los proporciona el sistema operativo.
s.bind(("", 9999))
# Le indicamos que espere una conexión entrante
s.listen(1)
# Aceptamos una conexión, como un nuevo socket (sc) y con los datos de la dirección del socket cliente (addr)
sc, addr = s.accept()

while True:
    # Leemos todos los bytes que nos lleguen:
    recibido = sc.recv(1024)
    # Si el mensaje es close se cierra la conexión
    if recibido.decode() == "close":
        break
    # Se muestra el mensaje enviado por el cliente
    print(str(addr[0]) + " dice: ", recibido.decode())
    # Se envia el mensaje recibido
    sc.send(recibido)
# Se despide el servidor 
print("Adios.")
# se cierra conexión
sc.close()
s.close()
