# Ejercicio 5: Servidor resistente a fallos en la transmisión a nivel de aplicación   
# Seminario 4: Seminario aplicación cliente - servidor conexión TCP
# Fundamentos de Redes (FR)
# Autor: Rafael Alejandro Rodríguez Gómez - rodgom@ugr.es
# Curso 2023 - 2024

import socket
import random

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(("", 9999))
s.listen(1)
sc, addr = s.accept()
msg_retry = "Retry"
msg_ack = "ACK"
while True:
    recibido = sc.recv(1024)
    if recibido.decode() == "close":
        break
    else:
        number = random.randint(1, 3)
        if number == 1:
            recibido = 0
            sc.send(msg_retry.encode())
            print("Mensaje de " + str(addr[0]) + " eliminado y retransmisión solicitada")
        else:
            sc.send(msg_ack.encode())
            print("Mensaje de " + str(addr[0]) + " guardado y ACK enviado")
            print(str(addr[0]) + " dice: " + recibido.decode())
print("Adiós")
sc.close()
s.close()
