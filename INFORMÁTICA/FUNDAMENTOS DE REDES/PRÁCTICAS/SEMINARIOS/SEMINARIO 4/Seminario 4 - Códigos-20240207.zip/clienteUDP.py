# Ejercicio 1: Cliente UDP  
# Seminario 4: Seminario aplicación cliente - servidor 
# Fundamentos de Redes (FR)
# Autor: Julia Caleya Sánchez - jcaleyas@ugr.es 
# Curso 2023 - 2024

import socket
# creamos un socket UDP (desde la aplicación se ve como un stream de bytes)
s_client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# enviamos los datos al socket remoto (no debe estar previamente conectado), el primer argumento son
#los bytes a enviar y el segundo argumento la dirección del socket remoto con el par indicado en socket.AF_INET
bytes = s_client.sendto(b'Hola clase', ('localhost',12345))
print("Mensaje enviado del tamaño: ", bytes)
data, serveraddr = s_client.recvfrom(4096)
print("Mensaje recibido: ", data.decode())
# cerramos la conexión
s_client.close()
