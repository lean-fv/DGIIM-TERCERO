# Ejercicio 4: Cliente TCP que envía un mensaje y el servidor lo devuelve en minusculas
# Seminario 4: Seminario aplicación cliente - servidor 
# Fundamentos de Redes (FR)
# Autor: Julia Caleya Sánchez - jcaleyas@ugr.es 
# Curso 2023 - 2024

import socket

# creamos un socket TCP (desde la aplicación se ve como un stream de bytes)
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# conectamos a un socket remoto
s.connect(("localhost", 9999))
while True:
    # solicitamos el mensaje que deseamos enviar
    mensaje = input("Mensaje a enviar >> ")
    # enviamos el mensaje que se ha recibido del terminal
    s.send(mensaje.encode())
    # si el mensaje es close entonces se cierra la conexion
    if mensaje == "close":
        s.send(mensaje.encode())
        break
    else:
        recibido = s.recv(1024)
        print("Mensaje recibido: ", recibido.decode())
# enviamos el mensaje de despedida
print("Adios.")
# se cierra conexión
s.close()
