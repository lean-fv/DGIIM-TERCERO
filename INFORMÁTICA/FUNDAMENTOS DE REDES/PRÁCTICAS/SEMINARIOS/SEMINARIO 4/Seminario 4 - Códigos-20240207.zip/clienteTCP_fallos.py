# Ejercicio 5: Cliente resistente a fallos en la transmisión a nivel de aplicación   
# Seminario 4: Seminario aplicación cliente - servidor conexión TCP
# Fundamentos de Redes (FR)
# Autor: Rafael Alejandro Rodríguez Gómez - rodgom@ugr.es
# Curso 2023 - 2024

import socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(("localhost", 9999))
s.settimeout(1)
while True:
    mensaje = input("Mensaje a enviar >> ")
    if mensaje == "close":
        s.send(mensaje.encode())
        break
    else:
        recibido = -1
        while recibido == -1:
            s.send(mensaje.encode())
            print("Mensaje " + mensaje + " enviado")
            recibido = s.recv(1024)
            if recibido.decode() == "ACK":
                print("ACK recibido para " + mensaje)
            else:
                if recibido.decode() == "Retry":
                    print("Solicitud de retransmisión recibida para " + mensaje)
                recibido = -1
print("Adiós")
s.close()
