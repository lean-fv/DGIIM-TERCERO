# Ejercicio 1: Servidor UDP  
# Seminario 4: Seminario aplicación cliente - servidor 
# Fundamentos de Redes (FR)
# Autor: Julia Caleya Sánchez - jcaleyas@ugr.es 
# Curso 2023 - 2024

import socket

# creamos un socket UDP (desde la aplicación se ve como un stream de bytes)
s_server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# indicamos en qué puerto debe escuchar. En los clientes no hace falta, los proporciona el sistema operativo.
s_server.bind(('',12345))
# esperamos la conexion con el cliente y la recepción de los datos
data, clientaddr = s_server.recvfrom(4096)
print(str(clientaddr) + " dice: ", data.decode())
if data.decode() == "Hola clase":
    s_server.sendto(b"Bienvenido a clase", (clientaddr))
    print("Mensaje enviado")
# se cierra conexión
s_server.close()
